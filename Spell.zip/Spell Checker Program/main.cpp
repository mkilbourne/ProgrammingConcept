//
//  main.cpp
//  Spell Checker Program
//
//  Created by Anthony Sessoms on 8/27/25.
//

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <unordered_set>
#include <cctype> // Include for isalpha

// Use an unordered_set for fast lookups
void loadDictionary(const std::string& filename, std::unordered_set<std::string>& words) {
    std::ifstream dictFile(filename);
    std::string word;
    if (dictFile.is_open()) {
        while (dictFile >> word) {
            std::transform(word.begin(), word.end(), word.begin(), ::tolower); // Add words in lowercase
            words.insert(word);
        }
        dictFile.close();
    } else {
        std::cerr << "Could not open dictionary file: " << filename << std::endl;
    }
}

void checkSpelling(const std::string& filename, const std::unordered_set<std::string>& words) {
    std::ifstream inputFile(filename);
    std::string word;
    if (inputFile.is_open()) {
        while (inputFile >> word) {
            // Remove non-alphabetic characters from the end of the word
            while (!word.empty() && !isalpha(word.back())) {
                word.pop_back();
            }
            // Remove non-alphabetic characters from the beginning of the word
            while (!word.empty() && !isalpha(word.front())) {
                word.erase(0, 1);
            }

            std::transform(word.begin(), word.end(), word.begin(), ::tolower);
            
            // Check if the sanitized word is in the unordered_set
            if (!word.empty() && words.find(word) == words.end()) {
                std::cout << "Misspelled word: " << word << std::endl;
            }
        }
        inputFile.close();
    } else {
        std::cerr << "Could not open the input file: " << filename << std::endl;
    }
}

int main() {
    std::unordered_set<std::string> dictionaryWords; // Change vector to unordered_set

    // Update the dictionary file path
    std::string dictionaryPath = "/Users/anthonysessoms/Desktop/Spell Checker Program/FRUIT.txt";
    loadDictionary(dictionaryPath, dictionaryWords);

    // Specify the input file path
    std::string inputFilePath = "/Users/anthonysessoms/Desktop/Spell Checker Program/input.txt";

    // Check spelling
    checkSpelling(inputFilePath, dictionaryWords);

    return 0;
}
